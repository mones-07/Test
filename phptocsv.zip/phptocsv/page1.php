<?php
$otp = (rand(100000,999999));
echo($otp);
echo('<br>');
$data=$_POST['textdata'];

	// Authorisation details.
	$username = "withbasharat07@gmail.com";
	$hash = "";

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	$test = "0";

	// Data for text message. This is the text message data.
	$sender = "TXTLCL"; // This is who the message appears to be from.
	$numbers = "91".$data; // A single number or a comma-seperated list of numbers
	$message = "The OTP for login is ".$otp;
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$message = urlencode($message);
	$data = "username=".$username."&hash=".$hash."&message=".$message."&sender=".$sender."&numbers=".$numbers."&test=".$test;
	$ch = curl_init('http://api.textlocal.in/send/?');
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);
?>

<!DOCTYPE html>
<html>
<head>
  <title>OTP Verification</title>
<script src="jquery.min.js"></script>
  <link rel="stylesheet" href="3.6_bootstrap.min.css" />
  <script src="3.7_bootstrap.min.js"></script>
<style> 
     body{ 
          text-align:center; 
         }
  </style>
</head>
<body>
  <form action="page2.php" method="post">
<!--    <p>  <font size="+2">Your Phone Number is: </font></p>
   <font size="+2"> <label class="control-label" ><?php echo $data; ?></label></font><br>

-->
     <font size="+2">Enter OTP Here:</font><br>
     <font size="+1"><input type="text" id="textdata" onkeyup="manage(this)"/></font><br><br>
   <font size="+2"> <input type="submit" id="submit" disabled /></font>
    
<script>
    function manage(txt) {
        var bt = document.getElementById('submit');
        if (textdata.value != <?php echo $otp; ?>) {
            bt.disabled = true;
        }
        else {
            bt.disabled = false;
        }
    }

</script>

  </form>
</body>
</html>