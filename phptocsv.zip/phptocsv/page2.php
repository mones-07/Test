<?php
//index.php

$error = '';
$parent_name = '';
$email = '';
$relations = '';
$phone = '';
$standard = '';

function clean_text($string)
{
 $string = trim($string);
 $string = stripslashes($string);
 $string = htmlspecialchars($string);
 return $string;
}

if(isset($_POST["submit"]))
{
 if(empty($_POST["parent_name"]))
 {
  $error .= '<p><label class="text-danger">Please Enter your Name</label></p>';
 }
 else
 {
  $parent_name = clean_text($_POST["parent_name"]);
  if(!preg_match("/^[a-zA-Z ]*$/",$parent_name))
  {
   $error .= '<p><label class="text-danger">Only letters and white space allowed</label></p>';
  }
 }


 if(empty($_POST["email"]))
 {
  $email= '';
 }
 else
 {
  $email = clean_text($_POST["email"]);
  if(!filter_var($email, FILTER_VALIDATE_EMAIL))
  {
   $error .= '<p><label class="text-danger">Invalid email format</label></p>';
  }
 }



 if(empty($_POST["relations"]))
 {
  $error .= '<p><label class="text-danger">Relation with student is required</label></p>';
 }
 else
 {
  $relations = clean_text($_POST["relations"]);
 }


 if(empty($_POST["phone"]))
 {
  $error .= '<p><label class="text-danger">Contact No. is required</label></p>';
 }
 else
 {
  $phone = clean_text($_POST["phone"]);
 }
if(empty($_POST["standard"]))
 {
  $error .= '<p><label class="text-danger">Standard of student is required</label></p>';
 }
 else
 {
  $standard = clean_text($_POST["standard"]);
 }
 if($error == '')
 {
  $file_open = fopen("data.csv", "a");
  $no_rows = count(file("data.csv"));
  if($no_rows > 1)
  {
   $no_rows = ($no_rows - 1) + 1;
  }
  $form_data = array(
   'Sr_no'  => $no_rows,
   'Parent\'s name'  => $parent_name,
   'Relation'  => $relations,
   'Standard' => $standard,
   'E-mail' => $email,
   'Contact No.' => $phone
  );
  fputcsv($file_open, $form_data);
  $error = '<label class="text-success">Thank you for contacting us.</label>';
  $parent_name = '';
  $email = '';
  $relations = '';
  $phone = '';
  $standard = '';
 }
}

?>


<!DOCTYPE html>
<html>
 <head>
  <title>Form</title>
  <script src="jquery.min.js"></script>
  <link rel="stylesheet" href="3.6_bootstrap.min.css" />
  <script src="3.7_bootstrap.min.js"></script>
 </head>
 <body>
  <br />
  <div class="container">
   <h2 align="center" style="color:darkred;">I've invited you to fill in a form</h2>
   <br />
<h2 align="center" style="color:darkolivegreen;">দি স্কটিশ চার্চ কলেজিয়েট স্কুল অভিভাবক ফোরামের উদ্যোগে অনলাইন সই সংগ্রহ (Online Signature Collection, An Initiative by SCCS Guardians' Forum) </h2>
<br />
<p>মহাশয়, </p>

<p>আমরা নিম্নলিখিত স্বাক্ষরকারীরা আপনার স্কুলের ছাত্রদের বাবা, মা এবং অভিভাবক। আমরা সম্মিলিতভাবে এই আবেদন পত্রের মাধ্যমে আপনার কাছে এবং আপনার মাধ্যমে স্কুল কর্তৃপক্ষের কাছে আমাদের কিছু অসুবিধার কথা তুলে ধরতে চাই। একথা আপনাকে বলার অপেক্ষা রাখেনা যে কোভিড - ১৯ জনিত পরিস্থিতিতে সমগ্র ভারতবর্ষের মতো আমরাও, আপনার স্কুলের ছাত্রদের অভিভাবকরাও, প্রত্যেকেই আকস্মিক ভাবে নানান আর্থিক দুরাবস্থার মধ্যে পড়ে গেছি। স্কুলের বেশিরভাগ অভিভাবকই মধ্যবিত্ত, নিম্নবিত্ত, গরিব ঘরের।আগামী দিনে শুধুমাত্র খেয়ে-পড়ে বেঁচে থাকাটাই আমাদের কাছে কঠিন হয়ে পড়বে। </p>
<p> এই পরিস্থিতিতে আমরা সত্যিই স্কুলের মাসিক ফি'র আর্থিক দায়ভার বহন করতে অক্ষম হয়ে পড়বো, আবার স্কুল কর্তৃপক্ষের বাধ্যবাধকতাও আমরা বুঝি, অনুভব করি। তাই আমরা সকলে সম্মিলিতভাবে আপনার কাছে আবেদন জানাই যে ----- </p>

<p> ১) এপ্রিল-মে ও জুন মাসের ডেভলপমেন্ট ও কম্পিউটার ফি বাদ দিয়ে আমাদের কাছ থেকে শুধুমাত্র টিউশন ফি নেওয়া হোক। </p>

<p> ২) কিছু অভিভাবক সত্যিই আছেন যারা টিউশন ফি টুকুও দিতে পারবেন না। স্কুল যেন তাদের সমস্ত ফি'টাই মুকুব করে তার ছাত্রকে স্কুলে পড়া চালিয়ে যাবার অধিকার দেয়। </p>

<p> ৩) ২৮/০৪/২০২০ র নোটিশ বাতিল করা হোক। </p>

<p> আশাকরি আপনি ও স্কুল কর্তৃপক্ষ আমাদের এই আবেদনের প্রতি সহানুভূতশীল হবেন ও আমাদের আবেদনের মান্যতা দিয়ে পাশে দাঁড়াবেন। </p>

<p> ধন্যবাদন্তে </p>
<br />
   <div class="col-md-6" style="margin:0 auto; float:none;">
    <form method="post" >
     <h3 align="center">Contact Form</h3>
     <br />
     <?php echo $error; ?>


     <div class="form-group">
      <label>অভিভাবক হিসাবে আপনার নাম [Your Name as a Guardian]</label>
      <input type="text" name="parent_name" placeholder="অভিভাবক হিসাবে আপনার নাম [Your Name as a Guardian]" class="form-control" value="<?php echo $parent_name; ?>" />
     </div>


    <div class="form-group">
    <label>আপনার সঙ্গে আপনার ছাত্রের সম্পর্ক [Relationship between you and your Student]</label>
   
    <input type="radio" name="relations" option value="Father" value="<?php echo $relations; ?>" />
    <label>বাবা [father]</label><br>  
    
    <input type="radio" name="relations" option value="Mother" value="<?php echo $relations; ?>" />
    <label>মা [mother]</label><br>

    <input type="radio" name="relations" option value="Other" value="<?php echo $relations; ?>" />
    <label> Other</label>
    </div>

    <div class="form-group">
    <label><b>আপনার ছাত্রের ক্লাস / শ্রেণী [Class of your Student]:</b></label>
    <br> <label for="standard">Choose Class:</label>
    <select id="class" name="standard" value="<php echo $standard; ?>">
    <option value="LN">Lower Nursery</option>
    <option value="UN">Upper Nursery</option>
    <option value="transition">Transition</option>
    <option value="1">I</option>
    <option value="2">II</option>
    <option value="3">III</option>
    <option value="4">IV</option>
    <option value="5">V</option>
    <option value="6">VI</option>
    <option value="7">VII</option>
    <option value="8">VIII</option>
    <option value="9">IX</option>
    <option value="10">X</option>
    <option value="11">XI</option>
    <option value="12">XII</option>

  </select></br>
    </div>
<br>


     <div class="form-group">
      <label>Enter Email</label>
      <input type="text" name="email" class="form-control" placeholder="Enter Email" value="<?php echo $email; ?>" />
     </div>


     <div class="form-group">
      <label>Enter Contact No.</label>
      <input type="text" name="phone" class="form-control" placeholder="Enter Phone No." value="<?php echo $phone; ?>" />
     </div>
     

     <div class="form-group" align="center">
      <input type="submit" name="submit" class="btn btn-info" value="Submit" />
     </div>
    <br>
    <br>
    </form>
   </div>
  </div>
 </body>
</html>